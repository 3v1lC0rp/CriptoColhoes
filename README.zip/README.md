# CriptoColhoes

CriptoColhoes é uma lotaria semanal parecida com o Euromilhões.

A maior parte do código é um fork do contrato de lotaria da PancakeSwap.
